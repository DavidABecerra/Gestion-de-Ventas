/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import model.Client;
import model.Product;
import model.Receipt;
import view.ReceiptView;

/**
 *
 * @author andresforero
 */
public class MainController {
    
    //Attributes
    private final ReceiptView receiptView;
    private Receipt receipt;
    private Product product;
    private String receiptInfo;
    private Double discount;
    private int amount;

    //Construct
    public MainController(){
        receiptView = new ReceiptView();
        receiptInfo = "Aún no se ha registrado ninguna venta";
        menu();
    }

    //Shows user menu
    private void menu(){
        switch(receiptView.showMenu()){
            case 1: sellRegist();
                            break;
            case 2: receiptPrint();
                            break;
            default: break;
        }
    }
    
    //Regist new Receipt
    //Manual
    public void sellRegist(){
        receipt = new Receipt();
        
        String[] clientData = receiptView.addClient();
        Client client = new Client(Integer.parseInt(clientData[0]), clientData[1], clientData[2], clientData[3], clientData[4]);
        receipt.setClient(client);
        
        String[] productData = receiptView.addProduct();
        product = new Product(productData[0], productData[1], Integer.parseInt(productData[2]), new Double(productData[3]), Integer.parseInt(productData[4]));
        receipt.setProduct(product);
        
        int amount = receiptView.getProductAmount();
        
        if(product.getStock() >= amount){
            //receiptInfo = receiptInfo + "El stock actual del producto " + product.getName() +" es:" +product.getStock());
            receiptInfo = "El stock actual del producto " + product.getName() +" es:" + product.getStock();
            //Info venta
            setInfo(amount);
            //
            receiptInfo += "\nEn la factura " + receipt.getId() + ", el cliente "+ client.getFirstName() + 
                    " compró " + product.getName() +"\n Total factura: " + receipt.getTotalPrice()+
                    "\n Descuento: "+discount+"\n Total Definitivo: "+(receipt.getTotalPrice() - discount);

            //Reducir cantidad
            product.updateStock(amount);
            receiptInfo += "\nEl stock actual del producto " + product.getName() +" es:" +product.getStock();	

        }else{
            receiptInfo = "No hay suficiente stock para vender";
        }
        
        receiptPrint();
        
    }

    //Método para calcular el valor total de la factura
    public void setInfo(int amount){
        receipt.setAmount(amount);
        //this.setTotalPrice(this.getAmount() * this.getProduct().getSellPrice());
        double totalPrice = receipt.getAmount() * product.getSellPrice();
        receipt.setTotalPrice(totalPrice);
        setSellDiscount();
    }

    //Método para calcular el descuento a aplicar
    public void setSellDiscount(){
        if((receipt.getTotalPrice() >= 0) && (receipt.getTotalPrice() <= 10000)){
                discount = receipt.getTotalPrice() * Receipt.FIRST_DISCOUNT;
        }else if((receipt.getTotalPrice() >= 10001) && (receipt.getTotalPrice() <= 20000)){
                discount = receipt.getTotalPrice() * Receipt.SECOND_DISCOUNT;
        }else{
                discount = receipt.getTotalPrice() * Receipt.THIRD_DISCOUNT;
        }

        //totalPrice = totalPrice - discount;
    }
    
    //Método para imrpimir la información de la última factura
    public void receiptPrint(){
        receiptView.receiptPrint(receiptInfo);
        menu();
    }


    
    public String buyRegist(Product product, int amount){
		String buyInfo = "";
		if(product == null){
			this.product = product;
		}
                
                               
               this.amount = amount;
                double totalPrice = this.amount * product.getSellPrice();
	
        
 		buyInfo += "\nSe compraron " + amount + product + "\nEl valor neto a pagar es de: " + totalPrice ;

 		 		//Aumentar cantidad
			
			buyInfo += "\nEl stock actual del producto " + product.getName() +" es:" + product.getStock();
		

		return buyInfo;
	}


	
	

        //Runner
    public static void main(String[] args) {
        MainController mainController = new MainController();
    }
}
