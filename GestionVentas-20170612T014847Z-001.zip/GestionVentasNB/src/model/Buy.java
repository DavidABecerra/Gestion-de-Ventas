/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author Los ROCKdriguez
 */
public class Buy {
    private double id;
	private Date buyDate;
	private double totalPrice;
	private int amount;
	private Product product;
	private double discount;
	private double discountPrice;

    public Buy(double id, Date buyDate, double totalPrice, int amount, Product product, double discount, double discountPrice) {
        this.id = id;
        this.buyDate = buyDate;
        this.totalPrice = totalPrice;
        this.amount = amount;
        this.product = product;
        this.discount = discount;
        this.discountPrice = discountPrice;
    }

    public double getId() {
        return id;
    }

    public void setId(double id) {
        this.id = id;
    }

    public Date getBuyDate() {
        return buyDate;
    }

    public void setBuyDate(Date buyDate) {
        this.buyDate = buyDate;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public double getDiscountPrice() {
        return discountPrice;
    }

    public void setDiscountPrice(double discountPrice) {
        this.discountPrice = discountPrice;
    }
        
        

    
}
