/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author andresforero
 */
public class Receipt {
    //Constats
    public static final double FIRST_DISCOUNT = 0.03;
    public static final double SECOND_DISCOUNT = 0.05;
    public static final double THIRD_DISCOUNT = 0.07;

    //Attributes
    private double id;
    private Date sellDate;
    private double totalPrice;
    private int amount;
    private double discount;
    private Product product;
    private Client client;
    
    //Construct
    public Receipt(double id, Date sellDate, double totalPrice, int amount, double discount, Product product, Client client) {
        this.id = id;
        this.sellDate = sellDate;
        this.totalPrice = totalPrice;
        this.amount = amount;
        this.discount = discount;
        this.product = product;
        this.client = client;
    }
    
    //Construct2
    public Receipt(){
            this.id = 1;
            this.sellDate = new Date();
    }
    
    //Getter and Setter
    public double getId() {
        return id;
    }

    public void setId(double id) {
        this.id = id;
    }

    public Date getSellDate() {
        return sellDate;
    }

    public void setSellDate(Date sellDate) {
        this.sellDate = sellDate;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }
    
}
