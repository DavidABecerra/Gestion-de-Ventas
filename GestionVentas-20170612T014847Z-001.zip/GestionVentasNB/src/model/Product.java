/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author andresforero
 */
public class Product {
    //Constants
    public static final int TIPO_SUPERMERCADO = 0;
    public static final int TIPO_DROGUERIA = 1;
    public static final int TIPO_PAPELERIA = 2;

    //Attributes
    private String barcode; 
    private String name; 
    private int stock; 
    private double sellPrice;
    private int productType;

    //Construct
    public Product(String barcode, String name, int stock, double sellPrice, int productType){
        this.barcode = barcode;	
        this.name = name;	
        this.stock = stock;	
        this.sellPrice = sellPrice;	
        this.productType = productType;	
    }

    //Inherit methods
    public String getBarcode(){
        return barcode;
    }

    public void setBarcode(String barcode){
        this.barcode = barcode;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public int getStock(){
        return stock;
    }

    public void setStock(int stock){
        this.stock = stock;
    }

    public double getSellPrice(){
        return sellPrice;
    }

    public void setSellPrice(double sellPrice){
        this.sellPrice = sellPrice;
    }

    public int getProductType(){
        return productType;
    }

    public void setProductType(int productType){
        this.productType = productType;
    }

    //Manual methods
    public void updateStock(int sellAmount){
        this.stock = this.stock - sellAmount;
        //this.stock -= sellAmount;
    }

   }
