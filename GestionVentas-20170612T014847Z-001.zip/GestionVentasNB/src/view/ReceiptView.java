/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.util.Scanner;

/**
 *
 * @author andresforero
 */
public class ReceiptView {
    
    //Attributes
    private Scanner scanner;
    
    //Construct
    public ReceiptView(){
        scanner = new Scanner(System.in);
    }
    
    //Shows menu to user
    public int showMenu(){
        System.out.println("Selecciona una de las siguientes opciones: " +
                " \n 1. Para registrar una nueva factura " +
                " \n 2. Para imprimir la última factura creada" + 
                " \n 3. Para salir del programa");
        return Integer.parseInt(scanner.nextLine());
    }
    
    //Gets client Data
    public String[] addClient(){
        String[] clientData = new String[5];

        System.out.println("Ingresa la cedula del cliente: ");
        clientData[0] = scanner.nextLine();		

        System.out.println("Ingresa el nombre del cliente: ");
        clientData[1] = scanner.nextLine();		

        System.out.println("Ingresa el apellido del cliente: ");
        clientData[2] = scanner.nextLine();		

        System.out.println("Ingresa el teléfono del cliente: ");
        clientData[3] = scanner.nextLine();		

        System.out.println("Ingresa la dirección del cliente: ");
        clientData[4] = scanner.nextLine();		

        return clientData;
		
    }
    
    //Gets product Data
    public String[] addProduct(){
        
        String[] productData = new String[5];

        System.out.println("\n Ahora ingresa los datos del producto \ningresa el código de barras: ");
        productData[0] = scanner.nextLine();		

        System.out.println("ingresa el nombre: ");
        productData[1] = scanner.nextLine();		

        System.out.println("ingresa la cantidad disponible: ");
        productData[2] = scanner.nextLine();		

        System.out.println("ingresa el valor de venta: ");
        productData[3] = scanner.nextLine();		

        System.out.println("ingresa el tipo de producto:\nIngresa 0 si es de supermercado \nIngresa 1 si es de drogueria \nIngresa 2 si es de papeleria");
        productData[4] = scanner.nextLine();		

        return productData;
    }
    
    //Gets product's amount
    public int getProductAmount(){
        System.out.println("Ingresa la cantidad a vender: ");

        return Integer.parseInt(scanner.nextLine());
    }
    
    //Prints receipt info
    public void receiptPrint(String print){
        System.out.println("\n"+print+"\n");
    } 
}
